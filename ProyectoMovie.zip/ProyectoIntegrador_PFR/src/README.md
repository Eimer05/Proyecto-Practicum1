# ProyectoIntegrador_PFR
Repositorio del proyecto integrador - Programación funcional y reactica

Aquí tienes el contenido completo y estructurado para tu archivo **README.md**, diseñado para presentar formalmente los avances de tu proyecto integrador.


# Proyecto Integrador: Análisis de Datos con Programación Funcional

**Lenguaje:** Scala 2.13

**Gestor de Dependencias:** SBT

**Librerías Principales:** Circe (JSON), Scala-CSV

## 1. Estructura del Proyecto

Siguiendo los estándares de la programación funcional y la organización de SBT:

Nombre_Del_Repositorio/
├── build.sbt                # Configuración y dependencias (Circe)
├── src/
│   └── main/
│       ├── resources/       # Archivos de datos (.csv y .json)
│       └── scala/
│           ├── data/        # Case classes y modelos de datos
│           ├── models/      # Definiciones de dominio
│           ├── utilities/   # Lógica de procesamiento y limpieza
│           └── Main.scala   # Punto de entrada y ejecución
└── README.md                # Documentación del proyecto



## 2. Descripción de las Tablas de Datos

Se trabaja con un dataset de películas que contiene información técnica y financiera.

| Nombre de Columna | Tipo | Propósito | Observaciones |
| --- | --- | --- | --- |
| **id** | Integer | Identificador único | Llave primaria para cruce de datos. |
| **title** | String | Título de la película | - |
| **budget** | Double | Presupuesto | Contiene valores en 0 que requieren limpieza. |
| **revenue** | Double | Ingresos totales | Análisis de rentabilidad financiera. |
| **runtime** | Double | Duración | Se identifican valores nulos (vacíos). |
| **original_language** | String | Idioma original | Análisis de distribución de frecuencia. |
| **crew** | JSON | Personal técnico | Formato JSON complejo; requiere parseo con Circe. |


## 3. Avance 1: Análisis y Limpieza Inicial

### Lectura y Análisis Numérico

* **Lectura:** Carga de columnas `budget` y `revenue`.
* **Estadísticas Básicas:** Implementación de funciones puras para calcular la **Media**, **Máximo**, **Mínimo** y **Conteo** de registros válidos.
* **Análisis de Texto:** Se desarrolló un motor de distribución de frecuencias para la columna `original_language`, permitiendo identificar los idiomas predominantes mediante el paradigma funcional (`groupBy` + `mapValues`).

### Limpieza de Datos

* **Valores Nulos:** Se utiliza el tipo `Option[T]` y el método `flatten` para eliminar registros incompletos sin generar excepciones de puntero nulo.
* **Valores Atípicos:** Filtrado de registros con valores de presupuesto o ingresos iguales a cero para evitar sesgos en el análisis estadístico.


## 4. Avance 2: Procesamiento JSON y Librería Circe

### Implementación de Circe

Se integró la librería **Circe** para la manipulación de datos semiestructurados.

* **Aprendizaje:** Uso de un JSON simplificado para testear el decodificador (`decode[T]`).
* **Manejo de la Columna Crew:** * Se definieron Case Classes (`CrewMember`, `MovieCrew`) para mapear la estructura del JSON.
* Se implementó lógica funcional para filtrar roles específicos, permitiendo extraer únicamente a los **Directores** de cada producción.



### Documentación del Proceso

1. **Ingesta:** Los datos se leen desde `src/main/resources/`.
2. **Transformación:** Los strings JSON se convierten en objetos de Scala.
3. **Filtrado:** Se limpian los datos mediante funciones de orden superior (`filter`, `map`).
4. **Salida:** Los resultados se presentan en consola a través del objeto `Main`.


## 5. Instrucciones de Ejecución

Para ejecutar el análisis de datos, asegúrese de tener instalado SBT y ejecute:

sbt run
