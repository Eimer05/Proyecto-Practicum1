import utilities.DataProcessor
import scala.io.Source

object Main extends App {
  // Carga de archivos
  val csvPath = "src/main/resources/movies_data.csv"
  val jsonPath = "src/main/resources/crew_data.json"

  val rows = Source.fromFile(csvPath).getLines().drop(1).map(_.split(",").toList).toList

  // AVANCE 1
  val budgets = rows.map(r => r(2))
  println(s"Estadísticas de Presupuesto: ${DataProcessor.analyzeNumeric(budgets)}")

  val languages = rows.map(r => r(5))
  println(s"Distribución por Idioma: ${DataProcessor.getFrequency(languages)}")

  // AVANCE 2
  val jsonRaw = Source.fromFile(jsonPath).mkString
  val directors = DataProcessor.processCrew(jsonRaw)
  println(s"Directores Procesados (JSON): ${directors.mkString(", ")}")
}