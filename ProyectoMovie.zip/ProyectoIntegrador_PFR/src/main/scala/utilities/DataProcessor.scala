package utilities

import io.circe.generic.auto._
import io.circe.parser._

case class CrewMember(job: String, name: String)
case class MovieCrew(id: Int, crew: List[CrewMember])

object DataProcessor {

  // Avance 1: Análisis Numérico y Limpieza
  def analyzeNumeric(data: List[String]): Map[String, Double] = {
    val clean = data.flatMap(s => scala.util.Try(s.toDouble).toOption).filter(_ > 0)
    if (clean.isEmpty) Map.empty
    else Map(
      "Media" -> clean.sum / clean.size,
      "Max"   -> clean.max,
      "Min"   -> clean.min,
      "Count" -> clean.size.toDouble
    )
  }

  // Avance 1: Frecuencia de Texto
  def getFrequency(data: List[String]): Map[String, Int] = {
    data.filter(_.nonEmpty).groupBy(identity).mapValues(_.size).toMap
  }

  // Avance 2: Procesamiento de Crew con Circe
  def processCrew(jsonStr: String): List[String] = {
    decode[List[MovieCrew]](jsonStr) match {
      case Right(list) => list.flatMap(_.crew.filter(_.job == "Director").map(_.name))
      case Left(_) => Nil
    }
  }
}